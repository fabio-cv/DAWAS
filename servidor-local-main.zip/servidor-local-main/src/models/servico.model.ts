import db from "../lib/db.js";
import type { ServicoDBType } from "../utils/types.js";

export const ServicoModel = {
    async create(newService: ServicoDBType) {
        try {
            const query = `INSERT INTO tabela_servicos VALUES (?, ?, ?, ?, ?, ?, ?)`;

            const values = [
                null,
                newService.nome,
                newService.desconto,
                newService.categoria,
                newService.enabled,
                new Date(),
                new Date()
            ];

            const rows = await db.execute(query, values);

            return rows;
        } catch (error) {
            console.log(error);
            return null;
        }
    },
};
