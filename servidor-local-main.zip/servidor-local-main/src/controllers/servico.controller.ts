import { ServicoModel } from "../models/servico.model.js";
import { addServicesToDB } from "../servico.js";
import type { ServicoDBType } from "../utils/types.js";
import type { Request, Response } from "express";

const ServicoController = {
    async CreateServico(req: Request, res: Response) {
        const newService: ServicoDBType = req.body;

        if(!newService){
            return res.status(400).json({
                status: "error",
                message: "Dados de servico invalidos",
                data: null
            })
        }

        const createServicoResponse = await ServicoModel.create(newService);

        if(createServicoResponse === null){
            return res.status(400).json({
                status: "error",
                message: "Erro ao criar servico",
                data: null
            })
        }

        res.status(200).json({
            status: "success",
            message: "Servico criado com sucesso",
            data: createServicoResponse
        })
    }
}